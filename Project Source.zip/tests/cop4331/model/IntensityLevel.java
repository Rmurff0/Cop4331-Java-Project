package cop4331.model;

public enum IntensityLevel {
    LOW, MEDIUM, HIGH
}
