package cop4331.model;

import java.util.List;

public class WeeklyCaloriesStrategy implements GoalEvaluationStrategy {

    @Override
    public ProgressSummary evaluate(List<Workout> workouts, Goal goal) {
        double total = workouts.stream()
                .mapToDouble(Workout::getCaloriesBurned)
                .sum();
        boolean reached = total >= goal.getTargetCalories();
        return new ProgressSummary(total, reached);
    }
}

