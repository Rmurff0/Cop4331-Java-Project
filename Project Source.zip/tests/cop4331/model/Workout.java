package cop4331.model;

import java.time.LocalDate;

/**
 * Represents a single workout entry.
 * Preconditions: durationMinutes > 0
 * Postconditions: Workout object created with provided values.
 */
public class Workout {

    private int id;
    private LocalDate date;
    private String type;
    private int durationMinutes;
    private IntensityLevel intensity;
    private double caloriesBurned;

    public Workout(int id, LocalDate date, String type, int durationMinutes,
                   IntensityLevel intensity, double caloriesBurned) {
        this.id = id;
        this.date = date;
        this.type = type;
        this.durationMinutes = durationMinutes;
        this.intensity = intensity;
        this.caloriesBurned = caloriesBurned;
    }

    // ======== GETTERS =========

    public int getId() {
        return id;
    }

    public LocalDate getDate() {
        return date;
    }

    public String getType() {
        return type;
    }

    public int getDurationMinutes() {
        return durationMinutes;
    }

    public IntensityLevel getIntensity() {
        return intensity;
    }

    public double getCaloriesBurned() {
        return caloriesBurned;
    }

    // ======== SETTERS (optional) ========
    // Add these only if editing workouts is allowed in your UI

    public void setType(String type) {
        this.type = type;
    }

    public void setDurationMinutes(int durationMinutes) {
        this.durationMinutes = durationMinutes;
    }

    public void setIntensity(IntensityLevel intensity) {
        this.intensity = intensity;
    }

    public void setCaloriesBurned(double caloriesBurned) {
        this.caloriesBurned = caloriesBurned;
    }
}
