package tests;

import cop4331.model.*;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class WorkoutLogTest {

    @Test
    public void testAddWorkout() {
        WorkoutLog log = new WorkoutLog();
        Workout w = new Workout(1, LocalDate.now(), "Run", 30, IntensityLevel.MEDIUM, 250);

        log.addWorkout(w);

        assertEquals(1, log.getAllWorkouts().size());
    }
}
