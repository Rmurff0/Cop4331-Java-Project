package cop4331.model;

public class Goal {
    private double targetCalories;
    public Goal(double targetCalories) { this.targetCalories = targetCalories; }
    public double getTargetCalories() { return targetCalories; }
}

