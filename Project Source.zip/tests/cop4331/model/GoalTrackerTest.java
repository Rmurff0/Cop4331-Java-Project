package tests;

import cop4331.model.*;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class GoalTrackerTest {

    @Test
    public void testSetAndGetGoal() {
        GoalTracker tracker = new GoalTracker();
        Goal goal = new Goal(1500);

        tracker.setGoal(goal);

        assertEquals(1500, tracker.getCurrentGoal().getTargetCalories());
    }

    @Test
    public void testEvaluateProgressNoGoal() {
        GoalTracker tracker = new GoalTracker();

        List<Workout> workouts = List.of(
                new Workout(1, LocalDate.now(), "Run", 30, IntensityLevel.MEDIUM, 300)
        );

        ProgressSummary summary = tracker.evaluateProgress(workouts);

        assertEquals(0, summary.getTotalCalories());
        assertFalse(summary.isGoalReached());
    }

    @Test
    public void testEvaluateProgressGoalReached() {
        GoalTracker tracker = new GoalTracker();
        tracker.setGoal(new Goal(500));

        List<Workout> workouts = List.of(
                new Workout(1, LocalDate.now(), "Run", 30, IntensityLevel.MEDIUM, 300),
                new Workout(2, LocalDate.now(), "Bike", 45, IntensityLevel.MEDIUM, 250)
        );

        ProgressSummary summary = tracker.evaluateProgress(workouts);

        assertEquals(550, summary.getTotalCalories());
        assertTrue(summary.isGoalReached());
    }

    @Test
    public void testEvaluateProgressGoalNotReached() {
        GoalTracker tracker = new GoalTracker();
        tracker.setGoal(new Goal(1000));

        List<Workout> workouts = List.of(
                new Workout(1, LocalDate.now(), "Run", 30, IntensityLevel.MEDIUM, 300),
                new Workout(2, LocalDate.now(), "Bike", 45, IntensityLevel.MEDIUM, 250)
        );

        ProgressSummary summary = tracker.evaluateProgress(workouts);

        assertEquals(550, summary.getTotalCalories());
        assertFalse(summary.isGoalReached());
    }

    @Test
    public void testChangeStrategy() {
        GoalTracker tracker = new GoalTracker();
        GoalEvaluationStrategy strategy = new WeeklyCaloriesStrategy();

        tracker.setStrategy(strategy);

        assertNotNull(tracker);
    }
}

