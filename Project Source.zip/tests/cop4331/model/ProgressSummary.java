package cop4331.model;

public class ProgressSummary {
    private double totalCalories;
    private boolean goalReached;

    public ProgressSummary(double totalCalories, boolean goalReached) {
        this.totalCalories = totalCalories;
        this.goalReached = goalReached;
    }

    public double getTotalCalories() { return totalCalories; }
    public boolean isGoalReached() { return goalReached; }
}

