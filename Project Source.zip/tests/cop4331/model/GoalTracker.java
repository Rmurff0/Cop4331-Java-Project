package cop4331.model;

import java.util.List;

public class GoalTracker {

    private Goal currentGoal;
    private GoalEvaluationStrategy strategy;


    public GoalTracker() {
        this.strategy = new WeeklyCaloriesStrategy();
    }


    public void setGoal(Goal goal) {
        this.currentGoal = goal;
    }

    public Goal getCurrentGoal() {
        return currentGoal;
    }


    public void setStrategy(GoalEvaluationStrategy strategy) {
        if (strategy != null) {
            this.strategy = strategy;
        }
    }


    public ProgressSummary evaluateProgress(List<Workout> workouts) {
        if (currentGoal == null) {
            // No goal set → return 0 with "not reached"
            return new ProgressSummary(0, false);
        }
        return strategy.evaluate(workouts, currentGoal);
    }
}

