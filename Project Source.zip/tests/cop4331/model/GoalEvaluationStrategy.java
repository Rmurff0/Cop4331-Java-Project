package cop4331.model;

import java.util.List;

public interface GoalEvaluationStrategy {
    ProgressSummary evaluate(List<Workout> workouts, Goal goal);
}

