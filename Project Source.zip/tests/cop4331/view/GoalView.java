package cop4331.view;

import javax.swing.*;
import java.awt.*;

public class GoalView extends JPanel {

    public JTextField goalField = new JTextField(20);
    public JButton saveGoalBtn = new JButton("Save Goal");

    public GoalView() {
        setLayout(new GridLayout(2, 2, 10, 10));

        add(new JLabel("Weekly Calorie Goal:"));
        add(goalField);

        add(saveGoalBtn);
    }
}

