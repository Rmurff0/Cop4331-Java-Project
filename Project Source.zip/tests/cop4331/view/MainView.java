package cop4331.view;

import javax.swing.*;

public class MainView extends JFrame {

    public JButton addWorkoutBtn = new JButton("Add Workout");
    public JButton viewHistoryBtn = new JButton("View History");
    public JButton setGoalBtn = new JButton("Set Goal");
    public JButton summaryBtn = new JButton("Progress Summary");
    public JButton exportBtn = new JButton("Export CSV");
    public JButton saveBtn = new JButton("Save Data");

    public MainView() {
        setTitle("Fitness Tracker");
        setSize(400, 300);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        add(addWorkoutBtn);
        add(viewHistoryBtn);
        add(setGoalBtn);
        add(summaryBtn);
        add(exportBtn);
        add(saveBtn);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

