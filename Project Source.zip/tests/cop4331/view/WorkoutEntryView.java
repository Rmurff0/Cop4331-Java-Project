package cop4331.view;

import javax.swing.*;

public class WorkoutEntryView extends JPanel {

    public JTextField typeField = new JTextField(20);
    public JTextField durationField = new JTextField(20);
    public JComboBox<String> intensityBox = new JComboBox<>(new String[]{"LOW", "MEDIUM", "HIGH"});
    public JButton saveBtn = new JButton("Save");

    public WorkoutEntryView() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        add(new JLabel("Type:"));
        add(typeField);

        add(new JLabel("Duration:"));
        add(durationField);

        add(new JLabel("Intensity:"));
        add(intensityBox);

        add(saveBtn);
    }
}

