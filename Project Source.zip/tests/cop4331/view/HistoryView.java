package cop4331.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class HistoryView extends JPanel {

    public JTable workoutTable;
    public DefaultTableModel tableModel;

    public JButton filterBtn = new JButton("Apply Filter");
    public JButton clearFilterBtn = new JButton("Clear Filter");
    public JButton deleteBtn = new JButton("Delete Selected");
    public JButton editBtn = new JButton("Edit Selected");

    public JTextField filterTypeField = new JTextField(15);
    public JTextField filterDateField = new JTextField(15); // optional

    public HistoryView() {
        setLayout(new BorderLayout());

        // Table Setup
        tableModel = new DefaultTableModel(new String[]{
                "ID", "Date", "Type", "Duration", "Intensity", "Calories"
        }, 0);

        workoutTable = new JTable(tableModel);
        JScrollPane scroll = new JScrollPane(workoutTable);
        add(scroll, BorderLayout.CENTER);

        // Filter Panel
        JPanel filterPanel = new JPanel(new GridLayout(3, 2));
        filterPanel.add(new JLabel("Type:"));
        filterPanel.add(filterTypeField);
        filterPanel.add(new JLabel("Date (YYYY-MM-DD):"));
        filterPanel.add(filterDateField);

        filterPanel.add(filterBtn);
        filterPanel.add(clearFilterBtn);

        add(filterPanel, BorderLayout.NORTH);

        // Action Buttons
        JPanel actionPanel = new JPanel();
        actionPanel.add(editBtn);
        actionPanel.add(deleteBtn);

        add(actionPanel, BorderLayout.SOUTH);
    }
}

