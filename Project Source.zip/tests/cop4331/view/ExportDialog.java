package cop4331.view;

import javax.swing.*;
import java.io.File;

public class ExportDialog {

    public String chooseFileLocation() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Select Export Location");

        int result = chooser.showSaveDialog(null);

        if (result == JFileChooser.APPROVE_OPTION) {
            File selected = chooser.getSelectedFile();
            return selected.getAbsolutePath();
        }
        return null;
    }
}

