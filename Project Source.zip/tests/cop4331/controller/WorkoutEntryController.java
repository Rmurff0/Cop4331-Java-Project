package cop4331.controller;

import cop4331.model.IntensityLevel;
import cop4331.model.Workout;
import cop4331.model.WorkoutLog;
import cop4331.view.WorkoutEntryView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WorkoutEntryController implements ActionListener {

    private WorkoutEntryView view;
    private WorkoutLog log;

    public WorkoutEntryController(WorkoutEntryView view, WorkoutLog log) {
        this.view = view;
        this.log = log;
        view.saveBtn.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        try {
            String type = view.typeField.getText();
            int duration = Integer.parseInt(view.durationField.getText());
            IntensityLevel level =
                    IntensityLevel.valueOf((String) view.intensityBox.getSelectedItem());

            double calories = duration * 6.5;

            Workout workout = new Workout(
                    log.getAllWorkouts().size() + 1,
                    java.time.LocalDate.now(),
                    type,
                    duration,
                    level,
                    calories
            );

            log.addWorkout(workout);
            JOptionPane.showMessageDialog(null, "Workout added successfully!");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Invalid input.");
        }
    }
}

