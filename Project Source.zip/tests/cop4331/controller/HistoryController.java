package cop4331.controller;

import cop4331.model.Workout;
import cop4331.model.WorkoutLog;
import cop4331.view.HistoryView;
import cop4331.view.WorkoutEntryView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

public class HistoryController implements ActionListener {

    private HistoryView view;
    private WorkoutLog log;

    public HistoryController(HistoryView view, WorkoutLog log) {
        this.view = view;
        this.log = log;

        view.filterBtn.addActionListener(this);
        view.clearFilterBtn.addActionListener(this);
        view.deleteBtn.addActionListener(this);
        view.editBtn.addActionListener(this);

        loadTableData(log.getAllWorkouts());
    }

    private void loadTableData(java.util.List<Workout> workouts) {
        view.tableModel.setRowCount(0);
        for (Workout w : workouts) {
            view.tableModel.addRow(new Object[]{
                    w.getId(),
                    w.getDate(),
                    w.getType(),
                    w.getDurationMinutes(),
                    w.getIntensity(),
                    w.getCaloriesBurned()
            });
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        Object src = e.getSource();

        if (src == view.filterBtn) {
            handleFilter();
        }

        if (src == view.clearFilterBtn) {
            loadTableData(log.getAllWorkouts());
        }

        if (src == view.deleteBtn) {
            handleDelete();
        }

        if (src == view.editBtn) {
            handleEdit();
        }
    }

    private void handleFilter() {
        String type = view.filterTypeField.getText();
        String dateStr = view.filterDateField.getText();

        java.util.List<Workout> list = log.getAllWorkouts();

        if (!type.isEmpty()) {
            list = list.stream()
                    .filter(w -> w.getType().equalsIgnoreCase(type))
                    .collect(java.util.stream.Collectors.toList());  // FIXED
        }

        if (!dateStr.isEmpty()) {
            try {
                LocalDate d = LocalDate.parse(dateStr);
                list = list.stream()
                        .filter(w -> w.getDate().equals(d))
                        .collect(java.util.stream.Collectors.toList());  // FIXED
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Invalid date.");
            }
        }

        loadTableData(list);
    }


    private void handleDelete() {
        int row = view.workoutTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(null, "Select a workout.");
            return;
        }
        int id = (int) view.tableModel.getValueAt(row, 0);
        log.removeWorkout(id);
        loadTableData(log.getAllWorkouts());
    }

    private void handleEdit() {
        int row = view.workoutTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(null, "Select a workout.");
            return;
        }

        int id = (int) view.tableModel.getValueAt(row, 0);
        Workout w = log.getAllWorkouts().stream()
                .filter(x -> x.getId() == id)
                .findFirst().orElse(null);

        if (w != null) {
            WorkoutEntryView editor = new WorkoutEntryView();
            new WorkoutEditController(editor, log, w);

            JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(view);
            frame.setContentPane(editor);
            frame.revalidate();
        }
    }
}

