package cop4331.controller;

import cop4331.model.DataStore;
import cop4331.model.GoalTracker;
import cop4331.model.WorkoutLog;

public class AppController {

    public static void saveData(WorkoutLog log, GoalTracker tracker) {
        DataStore.getInstance().saveData(log, tracker);
    }
}
