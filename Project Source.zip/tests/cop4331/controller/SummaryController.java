package cop4331.controller;

import cop4331.model.*;
import cop4331.view.SummaryView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SummaryController implements ActionListener {

    private SummaryView view;
    private WorkoutLog log;
    private GoalTracker tracker;

    public SummaryController(SummaryView view, WorkoutLog log, GoalTracker tracker) {
        this.view = view;
        this.log = log;
        this.tracker = tracker;

        loadSummary();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        loadSummary();
    }

    private void loadSummary() {
        Goal goal = tracker.getCurrentGoal();
        java.util.List<Workout> workouts = log.getAllWorkouts();

        ProgressSummary summary =
                tracker.evaluateProgress(workouts);

        view.updateSummary(summary.getTotalCalories(), summary.isGoalReached());
    }
}

