package cop4331.controller;

import cop4331.model.Goal;
import cop4331.model.GoalTracker;
import cop4331.view.GoalView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GoalController implements ActionListener {

    private GoalView view;
    private GoalTracker tracker;

    public GoalController(GoalView view, GoalTracker tracker) {
        this.view = view;
        this.tracker = tracker;
        view.saveGoalBtn.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            double goal = Double.parseDouble(view.goalField.getText());
            tracker.setGoal(new Goal(goal));
            JOptionPane.showMessageDialog(null, "Goal saved!");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid goal.");
        }
    }
}

