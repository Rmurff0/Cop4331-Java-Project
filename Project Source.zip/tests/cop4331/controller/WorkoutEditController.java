package cop4331.controller;

import cop4331.model.IntensityLevel;
import cop4331.model.Workout;
import cop4331.model.WorkoutLog;
import cop4331.view.WorkoutEntryView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WorkoutEditController implements ActionListener {

    private WorkoutEntryView view;
    private WorkoutLog log;
    private Workout workout;

    public WorkoutEditController(WorkoutEntryView view, WorkoutLog log, Workout workout) {
        this.view = view;
        this.log = log;
        this.workout = workout;

        loadWorkoutData();
        view.saveBtn.setText("Save Changes");
        view.saveBtn.addActionListener(this);
    }

    private void loadWorkoutData() {
        view.typeField.setText(workout.getType());
        view.durationField.setText(String.valueOf(workout.getDurationMinutes()));
        view.intensityBox.setSelectedItem(workout.getIntensity().toString());
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        try {
            workout.setType(view.typeField.getText());
            workout.setDurationMinutes(Integer.parseInt(view.durationField.getText()));
            workout.setIntensity(IntensityLevel.valueOf((String) view.intensityBox.getSelectedItem()));

            JOptionPane.showMessageDialog(null, "Workout updated!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Invalid update.");
        }
    }
}
