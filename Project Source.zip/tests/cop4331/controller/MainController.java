package cop4331.controller;

import cop4331.model.GoalTracker;
import cop4331.model.WorkoutLog;
import cop4331.view.*;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainController implements ActionListener {

    private MainView mainView;
    private WorkoutLog workoutLog;
    private GoalTracker goalTracker;

    public MainController(MainView mainView, WorkoutLog workoutLog, GoalTracker goalTracker) {
        this.mainView = mainView;
        this.workoutLog = workoutLog;
        this.goalTracker = goalTracker;

        mainView.addWorkoutBtn.addActionListener(this);
        mainView.viewHistoryBtn.addActionListener(this);
        mainView.setGoalBtn.addActionListener(this);
        mainView.summaryBtn.addActionListener(this);
        mainView.exportBtn.addActionListener(this);
        mainView.saveBtn.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        Object src = e.getSource();

        if (src == mainView.addWorkoutBtn) {
            WorkoutEntryView view = new WorkoutEntryView();
            new WorkoutEntryController(view, workoutLog);
            showPanel(view);
        }

        if (src == mainView.viewHistoryBtn) {
            HistoryView view = new HistoryView();
            new HistoryController(view, workoutLog);
            showPanel(view);
        }

        if (src == mainView.setGoalBtn) {
            GoalView view = new GoalView();
            new GoalController(view, goalTracker);
            showPanel(view);
        }

        if (src == mainView.summaryBtn) {
            SummaryView view = new SummaryView();
            new SummaryController(view, workoutLog, goalTracker);
            showPanel(view);
        }

        if (src == mainView.exportBtn) {
            ExportDialog dialog = new ExportDialog();
            new ExportController(dialog, workoutLog);
        }

        if (src == mainView.saveBtn) {
            AppController.saveData(workoutLog, goalTracker);
        }
    }

    private void showPanel(JPanel panel) {
        mainView.setContentPane(panel);
        mainView.revalidate();
        mainView.repaint();
    }
}
