package cop4331.controller;

import cop4331.model.WorkoutLog;
import cop4331.util.CSVExporter;
import cop4331.view.ExportDialog;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ExportController implements ActionListener {

    private ExportDialog dialog;
    private WorkoutLog log;

    public ExportController(ExportDialog dialog, WorkoutLog log) {
        this.dialog = dialog;
        this.log = log;

        actionPerformed(null); // auto-run
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String path = dialog.chooseFileLocation();
        if (path == null) return;

        try {
            CSVExporter.exportToCSV(log.getAllWorkouts(), path);
            JOptionPane.showMessageDialog(null, "Exported!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Export failed.");
        }
    }
}

