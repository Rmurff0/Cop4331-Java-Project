package cop4331.main;

import cop4331.controller.MainController;
import cop4331.model.GoalTracker;
import cop4331.model.WorkoutLog;
import cop4331.view.MainView;

public class Main {
    public static void main(String[] args) {

        WorkoutLog log = new WorkoutLog();
        GoalTracker tracker = new GoalTracker();

        MainView mainView = new MainView();
        MainController mainController = new MainController(mainView, log, tracker);

        mainView.setVisible(true);
    }
}

