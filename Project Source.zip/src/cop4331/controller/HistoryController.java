package cop4331.controller;

import cop4331.view.*;
import cop4331.model.*;

import javax.swing.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.util.stream.Collectors;

public class HistoryController implements ActionListener {

    private HistoryView view;
    private WorkoutLog log;
    private JFrame frame;
    private MainView mainView;

    public HistoryController(HistoryView view, WorkoutLog log, JFrame frame, MainView mainView) {
        this.view = view;
        this.log = log;
        this.frame = frame;
        this.mainView = mainView;

        view.filterBtn.addActionListener(this);
        view.clearFilterBtn.addActionListener(this);
        view.deleteBtn.addActionListener(this);
        view.editBtn.addActionListener(this);
        view.backBtn.addActionListener(this);

        loadTableData(log.getAllWorkouts());
    }

    private void loadTableData(java.util.List<Workout> workouts) {
        view.tableModel.setRowCount(0);
        for (Workout w : workouts) {
            view.tableModel.addRow(new Object[]{
                    w.getId(),
                    w.getDate(),
                    w.getType(),
                    w.getDurationMinutes(),
                    w.getIntensity(),
                    w.getCaloriesBurned()
            });
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == view.backBtn) {
            frame.setContentPane(mainView);
            frame.revalidate();
            frame.repaint();
            return;
        }

        Object src = e.getSource();

        if (src == view.filterBtn) {
            handleFilter();
        }

        if (src == view.clearFilterBtn) {
            loadTableData(log.getAllWorkouts());
        }

        if (src == view.deleteBtn) {
            handleDelete();
        }

        if (src == view.editBtn) {
            handleEdit();
        }
    }

    private void handleFilter() {
        String type = view.filterTypeField.getText();
        String dateStr = view.filterDateField.getText();

        java.util.List<Workout> list = log.getAllWorkouts();

        if (!type.isEmpty()) {
            list = list.stream()
                    .filter(w -> w.getType().equalsIgnoreCase(type))
                    .collect(Collectors.toList());
        }

        if (!dateStr.isEmpty()) {
            try {
                LocalDate d = LocalDate.parse(dateStr);
                list = list.stream()
                        .filter(w -> w.getDate().equals(d))
                        .collect(Collectors.toList());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Invalid date.");
            }
        }

        loadTableData(list);
    }

    private void handleDelete() {
        int row = view.workoutTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(null, "Select a workout first.");
            return;
        }

        int id = (int) view.tableModel.getValueAt(row, 0);
        log.removeWorkout(id);
        loadTableData(log.getAllWorkouts());
    }

    private void handleEdit() {
        int row = view.workoutTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(null, "Select a workout to edit.");
            return;
        }

        int id = (int) view.tableModel.getValueAt(row, 0);

        // find the workout by ID
        Workout w = log.getAllWorkouts().stream()
                .filter(x -> x.getId() == id)
                .findFirst()
                .orElse(null);

        if (w != null) {
            WorkoutEntryView editor = new WorkoutEntryView();
            new WorkoutEditController(editor, log, w, frame, mainView);

            frame.setContentPane(editor);
            frame.revalidate();
            frame.repaint();
        }
    }
}


