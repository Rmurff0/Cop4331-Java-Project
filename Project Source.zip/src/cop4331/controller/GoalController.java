package cop4331.controller;

import cop4331.view.*;
import cop4331.model.*;

import javax.swing.*;
import java.awt.event.*;

public class GoalController implements ActionListener {

    private GoalView view;
    private GoalTracker tracker;
    private JFrame frame;
    private MainView mainView;

    public GoalController(GoalView view, GoalTracker tracker, JFrame frame, MainView mainView) {
        this.view = view;
        this.tracker = tracker;
        this.frame = frame;
        this.mainView = mainView;

        view.saveGoalBtn.addActionListener(this);
        view.backBtn.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == view.backBtn) {
            frame.setContentPane(mainView);
            frame.revalidate();
            frame.repaint();
            return;
        }

        try {
            double goalVal = Double.parseDouble(view.goalField.getText());
            tracker.setGoal(new Goal(goalVal));
            JOptionPane.showMessageDialog(null, "Goal saved!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Invalid goal value.");
        }
    }
}


