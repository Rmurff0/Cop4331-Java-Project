package cop4331.controller;

import cop4331.view.*;
import cop4331.model.*;
import cop4331.util.CSVExporter;

import javax.swing.*;
import java.awt.event.*;

public class MainController implements ActionListener {

    private JFrame frame;
    private MainView mainView;
    private WorkoutLog workoutLog;
    private GoalTracker goalTracker;

    public MainController(JFrame frame, MainView mainView, WorkoutLog workoutLog, GoalTracker goalTracker) {
        this.frame = frame;
        this.mainView = mainView;
        this.workoutLog = workoutLog;
        this.goalTracker = goalTracker;

        mainView.addWorkoutBtn.addActionListener(this);
        mainView.viewHistoryBtn.addActionListener(this);
        mainView.setGoalBtn.addActionListener(this);
        mainView.summaryBtn.addActionListener(this);
        mainView.exportBtn.addActionListener(this);
        mainView.saveBtn.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        Object src = e.getSource();

        if (src == mainView.addWorkoutBtn) {
            WorkoutEntryView view = new WorkoutEntryView();
            new WorkoutEntryController(view, workoutLog, frame, mainView);
            showPanel(view);
        }

        if (src == mainView.viewHistoryBtn) {
            HistoryView view = new HistoryView();
            new HistoryController(view, workoutLog, frame, mainView);
            showPanel(view);
        }

        if (src == mainView.setGoalBtn) {
            GoalView view = new GoalView();
            new GoalController(view, goalTracker, frame, mainView);
            showPanel(view);
        }

        if (src == mainView.summaryBtn) {
            SummaryView view = new SummaryView();
            new SummaryController(view, workoutLog, goalTracker, frame, mainView);
            showPanel(view);
        }

        if (src == mainView.exportBtn) {
            ExportDialog dialog = new ExportDialog();
            new ExportController(dialog, workoutLog);
        }

        if (src == mainView.saveBtn) {
            AppController.saveData(workoutLog, goalTracker);
        }
    }

    private void showPanel(JPanel panel) {
        frame.setContentPane(panel);
        frame.revalidate();
        frame.repaint();
    }
}

