package cop4331.controller;

import cop4331.model.*;

public class AppController {

    public static void saveData(WorkoutLog log, GoalTracker tracker) {
        DataStore.getInstance().saveData(log, tracker);
    }
}
