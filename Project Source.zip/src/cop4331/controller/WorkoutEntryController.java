package cop4331.controller;

import cop4331.view.*;
import cop4331.model.*;

import javax.swing.*;
import java.awt.event.*;

public class WorkoutEntryController implements ActionListener {

    private WorkoutEntryView view;
    private WorkoutLog log;
    private JFrame frame;
    private MainView mainView;

    public WorkoutEntryController(WorkoutEntryView view, WorkoutLog log, JFrame frame, MainView mainView) {
        this.view = view;
        this.log = log;
        this.frame = frame;
        this.mainView = mainView;

        view.saveBtn.addActionListener(this);
        view.backBtn.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == view.backBtn) {
            frame.setContentPane(mainView);
            frame.revalidate();
            frame.repaint();
            return;
        }

        try {
            String type = view.typeField.getText();
            int duration = Integer.parseInt(view.durationField.getText());
            IntensityLevel level = IntensityLevel.valueOf(
                    (String) view.intensityBox.getSelectedItem()
            );

            double calories = duration * 6.5;

            Workout workout = new Workout(
                    log.getAllWorkouts().size() + 1,
                    java.time.LocalDate.now(),
                    type,
                    duration,
                    level,
                    calories
            );

            log.addWorkout(workout);
            JOptionPane.showMessageDialog(null, "Workout added successfully!");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Invalid input.");
        }
    }
}


