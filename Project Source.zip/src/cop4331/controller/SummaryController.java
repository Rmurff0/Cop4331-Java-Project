package cop4331.controller;

import cop4331.view.*;
import cop4331.model.*;

import javax.swing.*;
import java.awt.event.*;

public class SummaryController implements ActionListener {

    private SummaryView view;
    private WorkoutLog log;
    private GoalTracker tracker;
    private JFrame frame;
    private MainView mainView;

    public SummaryController(SummaryView view, WorkoutLog log, GoalTracker tracker, JFrame frame, MainView mainView) {
        this.view = view;
        this.log = log;
        this.tracker = tracker;
        this.frame = frame;
        this.mainView = mainView;

        view.backBtn.addActionListener(this);
        loadSummary();
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == view.backBtn) {
            frame.setContentPane(mainView);
            frame.revalidate();
            frame.repaint();
            return;
        }

        loadSummary();
    }

    private void loadSummary() {
        ProgressSummary summary = tracker.evaluateProgress(log.getAllWorkouts());
        view.updateSummary(summary.getTotalCalories(), summary.isGoalReached());
    }
}

