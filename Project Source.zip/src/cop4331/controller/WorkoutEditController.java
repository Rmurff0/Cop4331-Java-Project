package cop4331.controller;

import cop4331.view.*;
import cop4331.model.*;

import javax.swing.*;
import java.awt.event.*;

public class WorkoutEditController implements ActionListener {

    private WorkoutEntryView view;
    private WorkoutLog log;
    private Workout workout;
    private JFrame frame;
    private MainView mainView;

    public WorkoutEditController(WorkoutEntryView view, WorkoutLog log, Workout workout, JFrame frame, MainView mainView) {
        this.view = view;
        this.log = log;
        this.workout = workout;
        this.frame = frame;
        this.mainView = mainView;

        // populate fields
        view.typeField.setText(workout.getType());
        view.durationField.setText(String.valueOf(workout.getDurationMinutes()));
        view.intensityBox.setSelectedItem(workout.getIntensity().name());

        view.saveBtn.setText("Update Workout");
        view.saveBtn.addActionListener(this);
        view.backBtn.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == view.backBtn) {
            frame.setContentPane(mainView);
            frame.revalidate();
            frame.repaint();
            return;
        }

        try {
            workout.setType(view.typeField.getText());
            workout.setDurationMinutes(Integer.parseInt(view.durationField.getText()));
            workout.setIntensity(IntensityLevel.valueOf((String) view.intensityBox.getSelectedItem()));

            // update calories
            workout.setCaloriesBurned(workout.getDurationMinutes() * 6.5);

            JOptionPane.showMessageDialog(null, "Workout updated!");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Invalid input.");
        }
    }
}

