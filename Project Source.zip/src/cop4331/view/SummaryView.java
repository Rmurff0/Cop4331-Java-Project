package cop4331.view;

import javax.swing.*;
import java.awt.*;

public class SummaryView extends JPanel {

    public JLabel totalCaloriesLabel = new JLabel("Total Calories: 0");
    public JLabel goalReachedLabel = new JLabel("Goal Reached: No");
    public JButton backBtn = new JButton("Back");

    public SummaryView() {
        setLayout(new GridLayout(3, 1, 10, 10));

        totalCaloriesLabel.setHorizontalAlignment(SwingConstants.CENTER);
        goalReachedLabel.setHorizontalAlignment(SwingConstants.CENTER);

        add(totalCaloriesLabel);
        add(goalReachedLabel);
        add(backBtn);
    }

    public void updateSummary(double totalCalories, boolean reached) {
        totalCaloriesLabel.setText("Total Calories: " + totalCalories);
        goalReachedLabel.setText("Goal Reached: " + (reached ? "Yes" : "No"));
    }
}

