package cop4331.view;

import javax.swing.*;
import java.awt.*;

public class MainView extends JPanel {

    public JButton addWorkoutBtn = new JButton("Add Workout");
    public JButton viewHistoryBtn = new JButton("View History");
    public JButton setGoalBtn = new JButton("Set Goal");
    public JButton summaryBtn = new JButton("Progress Summary");
    public JButton exportBtn = new JButton("Export to CSV");
    public JButton saveBtn = new JButton("Save Data");

    public MainView() {
        setLayout(new GridLayout(6, 1, 10, 10));

        add(addWorkoutBtn);
        add(viewHistoryBtn);
        add(setGoalBtn);
        add(summaryBtn);
        add(exportBtn);
        add(saveBtn);
    }
}


