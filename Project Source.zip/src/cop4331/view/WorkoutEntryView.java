package cop4331.view;

import javax.swing.*;
import java.awt.*;

public class WorkoutEntryView extends JPanel {

    public JTextField typeField = new JTextField(20);
    public JTextField durationField = new JTextField(20);
    public JComboBox<String> intensityBox = new JComboBox<>(new String[]{"LOW", "MEDIUM", "HIGH"});
    public JButton saveBtn = new JButton("Save Workout");
    public JButton backBtn = new JButton("Back");

    public WorkoutEntryView() {
        setLayout(new GridLayout(5, 2, 10, 10));

        add(new JLabel("Workout Type:"));
        add(typeField);

        add(new JLabel("Duration (minutes):"));
        add(durationField);

        add(new JLabel("Intensity:"));
        add(intensityBox);

        add(saveBtn);
        add(backBtn);
    }
}


