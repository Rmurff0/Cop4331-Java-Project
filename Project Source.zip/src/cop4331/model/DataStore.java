package cop4331.model;

public class DataStore {

    private static DataStore instance;

    private DataStore() {}

    public static DataStore getInstance() {
        if (instance == null)
            instance = new DataStore();
        return instance;
    }

    public void saveData(WorkoutLog log, GoalTracker tracker) {
    }

}

