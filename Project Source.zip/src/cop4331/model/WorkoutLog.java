package cop4331.model;

import java.util.ArrayList;
import java.util.List;

public class WorkoutLog {

    private List<Workout> workouts = new ArrayList<>();

    public void addWorkout(Workout w) { workouts.add(w); }

    public void removeWorkout(int id) {
        workouts.removeIf(w -> w.getId() == id);
    }

    public List<Workout> getAllWorkouts() {
        return new ArrayList<>(workouts);
    }
}


