package cop4331.util;

import cop4331.model.Workout;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;


public class  CSVExporter {

    /**
     * Exports a list of workouts to a CSV file.
     *
     * @param workouts list of Workout objects to export
     * @param filePath full file path chosen by user (ex: C:/output/workouts.csv)
     * @throws IOException if the file cannot be written
     */
    public static void exportToCSV(List<Workout> workouts, String filePath) throws IOException {

        FileWriter writer = new FileWriter(filePath);

        // Write header row
        writer.write("ID,Date,Type,Duration,Intensity,Calories\n");

        // Write each workout row
        for (Workout w : workouts) {
            writer.write(
                    w.getId() + "," +
                            w.getDate() + "," +
                            safe(w.getType()) + "," +
                            w.getDurationMinutes() + "," +
                            w.getIntensity() + "," +
                            w.getCaloriesBurned() + "\n"
            );
        }

        writer.flush();
        writer.close();
    }

    /**
     * Safely formats strings for CSV.
     *
     * @param s input string
     * @return sanitized version without commas or quotes
     */
    private static String safe(String s) {
        if (s == null) return "";
        return s.replace(",", ";").replace("\"", "");
    }
}

