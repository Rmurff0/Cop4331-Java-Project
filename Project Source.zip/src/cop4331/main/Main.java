package cop4331.main;

import cop4331.model.*;
import cop4331.view.*;
import cop4331.controller.*;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        WorkoutLog log = new WorkoutLog();
        GoalTracker tracker = new GoalTracker();

        JFrame frame = new JFrame("Fitness Tracker");
        frame.setSize(400, 450);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        MainView mainView = new MainView();
        new MainController(frame, mainView, log, tracker);

        frame.setContentPane(mainView);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}

